import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class NotaInputScreen extends StatefulWidget {
  final String noteId;

  const NotaInputScreen({super.key, required this.noteId});

  @override
  _NotaInputScreenState createState() => _NotaInputScreenState();
}

class _NotaInputScreenState extends State<NotaInputScreen> {
  late TextEditingController _noteController;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _noteController = TextEditingController();
    _loadNoteData();
  }

  Future<void> _loadNoteData() async {
    final doc = await FirebaseFirestore.instance.collection('notes').doc(widget.noteId).get();

    if (doc.exists) {
      _noteController.text = doc['name'];
    }
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _updateNote() async {
    final updatedText = _noteController.text.trim();
    if (updatedText.isNotEmpty) {
      await FirebaseFirestore.instance
          .collection('notes')
          .doc(widget.noteId)
          .update({'name': updatedText});
    }
  }

  Future<void> _deleteNote() async {
    await FirebaseFirestore.instance.collection('notes').doc(widget.noteId).delete();
    Navigator.of(context).pop(); // Regresa a la pantalla principal
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Note'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: _deleteNote,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: TextField(
          controller: _noteController,
          decoration: const InputDecoration(
            labelText: 'Note',
            border: OutlineInputBorder(),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _updateNote,
        child: const Icon(Icons.save),
      ),
    );
  }
}
