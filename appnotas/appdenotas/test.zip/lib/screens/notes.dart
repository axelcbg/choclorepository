import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:appdenotas/screens/nota_input.dart';

class NotesHomeScreen extends StatelessWidget {
  const NotesHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notes App'),
        elevation: 0,
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: theme.colorScheme.onPrimary,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 16),
          _buildSectionTitle('Quick Notes', context),
          _buildQuickNotesSection(context, theme),
          const SizedBox(height: 20),
          _buildSectionTitle('All Notes', context),
          _buildNotesList(context),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddNoteDialog(context),
        backgroundColor: theme.colorScheme.primary,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildSectionTitle(String title, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleLarge,
      ),
    );
  }

  Widget _buildQuickNotesSection(BuildContext context, ThemeData theme) {
    return SizedBox(
      height: 150,
      child: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('quick_notes').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final quickNotes = snapshot.data?.docs ?? [];

          return ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: quickNotes.length + 1,
            itemBuilder: (context, index) {
              if (index == quickNotes.length) {
                return IconButton(
                  onPressed: () => _showAddQuickNoteDialog(context),
                  icon: const Icon(Icons.add),
                  color: theme.colorScheme.primary,
                  iconSize: 50,
                );
              }
              final note = quickNotes[index];
              return _buildQuickNoteCard(
                context,
                theme,
                note.id,
                note['title'] ?? 'Untitled',
                note['text'] ?? '',
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildQuickNoteCard(BuildContext context, ThemeData theme, String id, String title, String text) {
    return GestureDetector(
      onTap: () => _showEditQuickNoteDialog(context, id, title, text),
      child: Container(
        width: 120,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: theme.colorScheme.secondary,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.onSecondary,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              text,
              style: TextStyle(
                color: theme.colorScheme.onSecondary,
                fontSize: 12,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
            IconButton(
              icon: const Icon(Icons.delete, size: 18),
              onPressed: () => _deleteQuickNoteDialog(context, id),
              color: theme.colorScheme.onSecondary,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotesList(BuildContext context) {
    return Expanded(
      child: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('notes').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final notes = snapshot.data?.docs ?? [];

          return ListView.builder(
            itemCount: notes.length,
            itemBuilder: (context, index) {
              final note = notes[index];
              return _buildNoteTile(
                context,
                note.id,
                note['name'] ?? 'Untitled',
                (note['timestamp'] as Timestamp).toDate(),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildNoteTile(BuildContext context, String id, String name, DateTime timestamp) {
    return ListTile(
      leading: const Icon(Icons.notes),
      title: Text(name),
      subtitle: Text('${timestamp.day}-${timestamp.month}-${timestamp.year}'),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NotaInputScreen(noteId: id),
          ),
        );
      },
    );
  }

  void _showAddQuickNoteDialog(BuildContext context) {
    final titleController = TextEditingController();
    final textController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Add Quick Note'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              TextField(
                controller: textController,
                decoration: const InputDecoration(labelText: 'Text'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final title = titleController.text.trim();
                final text = textController.text.trim();
                if (title.isNotEmpty) {
                  FirebaseFirestore.instance.collection('quick_notes').add({
                    'title': title,
                    'text': text,
                  });
                }
                Navigator.of(context).pop();
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  void _deleteQuickNoteDialog(BuildContext context, String id) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Delete Quick Note'),
          content: const Text('Are you sure you want to delete this quick note?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                FirebaseFirestore.instance.collection('quick_notes').doc(id).delete();
                Navigator.of(context).pop();
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  void _showAddNoteDialog(BuildContext context) {
    final nameController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Add Note'),
          content: TextField(
            controller: nameController,
            decoration: const InputDecoration(labelText: 'Note Name'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final name = nameController.text.trim();
                if (name.isNotEmpty) {
                  FirebaseFirestore.instance.collection('notes').add({
                    'name': name,
                    'timestamp': Timestamp.now(),
                  });
                }
                Navigator.of(context).pop();
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  void _showEditQuickNoteDialog(BuildContext context, String id, String title, String text) {
    final titleController = TextEditingController(text: title);
    final textController = TextEditingController(text: text);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Quick Note'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              TextField(
                controller: textController,
                decoration: const InputDecoration(labelText: 'Text'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final updatedTitle = titleController.text.trim();
                final updatedText = textController.text.trim();
                if (updatedTitle.isNotEmpty) {
                  FirebaseFirestore.instance.collection('quick_notes').doc(id).update({
                    'title': updatedTitle,
                    'text': updatedText,
                  });
                }
                Navigator.of(context).pop();
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }
}
