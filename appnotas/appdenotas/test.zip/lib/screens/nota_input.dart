import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class NotaInputScreen extends StatefulWidget {
  final String noteId; // ID de la nota en Firestore

  const NotaInputScreen({super.key, required this.noteId});

  @override
  _NotaInputScreenState createState() => _NotaInputScreenState();
}

class _NotaInputScreenState extends State<NotaInputScreen> {
  late TextEditingController _titleController; // Controlador para el título
  late TextEditingController _contentController; // Controlador para el contenido
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController();
    _contentController = TextEditingController();
    _loadNoteData();
  }

  Future<void> _loadNoteData() async {
    final doc = await FirebaseFirestore.instance
        .collection('notes')
        .doc(widget.noteId)
        .get();

    if (doc.exists) {
      _titleController.text = doc['name']; // Cargar el título desde Firebase
      _contentController.text = doc['content'] ?? ''; // Cargar el contenido si existe
    }
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _updateNote() async {
    final updatedTitle = _titleController.text.trim();
    final updatedContent = _contentController.text.trim();

    if (updatedTitle.isNotEmpty) {
      await FirebaseFirestore.instance.collection('notes').doc(widget.noteId).update({
        'name': updatedTitle,
        'content': updatedContent, // Guardar también el contenido
      });
    }
  }

  Future<void> _deleteNote() async {
    await FirebaseFirestore.instance.collection('notes').doc(widget.noteId).delete();
    Navigator.of(context).pop(); // Regresar a la pantalla anterior
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Editar Nota'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: _deleteNote, // Eliminar la nota
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Campo para el título
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Título',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            // Campo para el contenido (multilínea)
            Expanded(
              child: TextField(
                controller: _contentController,
                maxLines: null, // Permitir múltiples líneas
                expands: true, // Expandir para llenar el espacio disponible
                textAlignVertical: TextAlignVertical.top, // Alinear al inicio
                textAlign: TextAlign.left, // Justificar a la izquierda
                decoration: const InputDecoration(
                  labelText: 'Contenido',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _updateNote, // Guardar cambios
        child: const Icon(Icons.save),
      ),
    );
  }
}
