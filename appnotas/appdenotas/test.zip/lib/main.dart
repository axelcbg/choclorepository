import 'package:flutter/material.dart';
import 'package:appdenotas/screens/splashscreen.dart'; // Importa SplashScreen
import 'package:appdenotas/screens/notes.dart'; // Importa Notes
import 'package:appdenotas/theme/theme.dart'; // Importa el tema
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  
  // Mensaje para confirmar inicialización
  
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light, // Usa el tema claro definido en AppTheme
      darkTheme: AppTheme.dark, // Usa el tema oscuro definido en AppTheme
      themeMode: ThemeMode.system, // Cambia según la configuración del sistema
      home: const SplashScreen(), // Primera pantalla será el SplashScreen
      routes: {
        '/home': (context) => const HomeScreen(), // Ruta para HomeScreen
        '/notes': (context) => const NotesHomeScreen(), // Ruta para Notes
      },
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Screen'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.pushNamed(context, '/notes'); // Navega a Notes
          },
          child: const Text('Ir a Notas'),
        ),
      ),
    );
  }
}
