package com.example.appdenotas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
